# -*- coding: utf-8 -*-
"""
Created on Wed Feb  9 15:07:10 2022

@author: abc
"""


import nltk
from nltk.corpus import stopwords

corpus = open('ObamaSpeech.txt', 'r').read()
corpus = corpus.lower()
    
words = nltk.word_tokenize(corpus)
for word in words:
    print("the word is :",word)
 


frequency_dist = nltk.FreqDist(words)

sorted(frequency_dist,key=frequency_dist.__getitem__
       ,reverse=True)[0:28]

large_words = dict( [(k,v) for k, v in frequency_dist.items() if len(k)>8] )

frequency_dist = nltk.FreqDist(words)

from wordcloud import WordCloud
import matplotlib.pyplot as plt

wordcloud = WordCloud(max_font_size=50, max_words=100, background_color="black").generate_from_frequencies(frequency_dist)
plt.figure()
plt.imshow(wordcloud, interpolation="bilinear")
plt.axis("off")
plt.show()