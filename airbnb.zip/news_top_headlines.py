# -*- coding: utf-8 -*-
"""
Created on Wed Apr  6 14:27:12 2022

@author: abc
"""



import pprint
import requests     # 2.19.1


secret = '56f93f8dbb854e74b87ab0b515a922ed'

url = 'https://newsapi.org/v2/top-headlines?'

parameters = {
    'q': 'Machine', # query phrase
    'pageSize': 20,  # maximum is 100
    'apiKey': secret # your own API key
}


response = requests.get(url, params=parameters)

response_json = response.json()
pprint.pprint(response_json)

#for i in response_json['articles']:print(i['title'])


from wordcloud import WordCloud
import matplotlib.pyplot as plt



text_combined = ''

for i in response_json['articles']:
    text_combined += i['title'] + ' ' 
    
print(text_combined[0:300])


wordcloud = WordCloud(max_font_size=40).generate(text_combined)
plt.figure()
plt.imshow(wordcloud, interpolation="bilinear")
plt.axis("off")
plt.show()
