# -*- coding: utf-8 -*-
"""
Created on Wed Feb  2 15:55:54 2022

@author: abc
"""

import re

line1 = 'start address: 0xA0, func1 address: 0xC0'
line2 = 'end address: 0xFF, func2 address: 0xB0'
