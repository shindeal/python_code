# -*- coding: utf-8 -*-
"""
Created on Wed Jan 26 15:34:12 2022

@author: abc
"""

def add():
    a=int(input("Enter the 1st number:"))
    b=int(input("Enter the 2nd number:"))
    sum= a+b
    print("Addition of number is",sum)

def mult():
    a=int(input("Enter the 1st number:"))
    b=int(input("Enter the 2nd number:"))
    mult= a*b
    print("Multiplication of number is",mult)

def div():
    a=int(input("Enter the 1st number:"))
    b=int(input("Enter the 2nd number:"))
    div= int(a/b)
    print("Multiplication of number is",div)

def main():
    add()
    mult()
    div()
   