# -*- coding: utf-8 -*-
"""
Created on Wed Feb  9 16:34:41 2022

@author: abc
"""

from nltk.tokenize import sent_tokenize, word_tokenize
import warnings

warnings.filterwarnings(action = 'ignore')

import gensim
from gensim.models import Word2Vec


sample = open("HotelReviews.txt","r")
s = sample.read()

f = s.replace("\n", " ")

data = []

for i in sent_tokenize(f):
    temp = []
    
    for j in word_tokenize(i):
       temp.append(j.lower())
       
data.append(temp)

model1 = gensim.models.Word2Vec(data, min_count = 1, 
                              size = 100, window = 5)
  
print("Cosine similarity between 'alice' " + 
               "and 'wonderland' - CBOW : ",
    model1.similarity('alice', 'wonderland'))
      
print("Cosine similarity between 'alice' " +
                 "and 'machines' - CBOW : ",
      model1.similarity('alice', 'machines'))