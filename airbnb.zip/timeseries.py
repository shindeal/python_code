

from twython import Twython
import json
import pandas as pd
import matplotlib.pyplot as plt
import regex
from matplotlib import dates as mpl_dates
from datetime import datetime, timedelta
import csv

with open("twitter_credentials.json","r") as file:
     creds=json.load(file)   
     
python_tweets = Twython(creds['CONSUMER_KEY'],creds['CONSUMER_SECRET'])

#Popular trends in the UK
trends = Twython.get_place_trends(python_tweets,id=23424975 )
        


################################part2#####################################
query = {'q':'Lady Gaga',
        'result_type':'trend',
        'count':500,
        'lang':'en'
        }

sample_return = python_tweets.search(**query)
dictx={  'created_at':[]} 

for status in python_tweets.search(**query)['statuses']:
    dictx['created_at'].append(status['created_at'])
   
    
    



  
  
#######################part5 time series############################
df2 = pd.DataFrame(dictx)
#df2.to_csv(r'C:\Users\abc\.spyder-py3\timeseries.csv', index=False)
#dictx['created_at'] = pd.to_datetime(dictx['created_at'],utc=True)
#df2['created_at'] = pd.to_datetime(df2['created_at'],utc=True)
#series = pd.read_csv(r'C:\Users\abc\.spyder-py3\timeseries.csv', header=0, index_col=0, parse_dates=True, squeeze=True)
#series.plot()
#plt.show()

#plt.plot(dictx['created_at'])
df2['created_at'] = pd.to_datetime(df2['created_at'],utc=True)
df7 = df2.sort_values(by='created_at',ascending=False)
plt.plot(df7['created_at'],marker='o', linestyle='dashed')



plt.title("Time series for trend #LadyGaga")
plt.ylabel('Daily Tweet Created Timings');





