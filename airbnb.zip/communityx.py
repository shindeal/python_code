# -*- coding: utf-8 -*-
"""
Created on Wed Mar 16 14:11:19 2022

@author: abc
"""

from cdlib import algorithms, viz
import networkx as nx




G_fb = nx.read_edgelist("chat_join_team_chat", create_using = nx.Graph(), nodetype=int)

coms=algorithms.louvain(G_fb, weight='weight', resolution=1.)
pos=nx.spring_layout(G_fb)

viz.plot_network_clusters(G_fb, coms,pos)
viz.plot_community_graph(G_fb, coms)

