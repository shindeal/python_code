# -*- coding: utf-8 -*-
"""
Created on Fri May 12 17:29:13 2023

@author: abc
"""

import pandas as pd
import numpy as np
import csv
import plotly.express as px




data = pd.read_csv("E:\power bi\customer\data.csv",encoding="ISO-8859-1")

print(data.head())
print(data.isnull().sum())
print(data.isnull().sum() * 100 / len(data)) #to know % of missing values

print(data.Country.value_counts()) #calculates unique values for each type

print(data.tail())

data.info() # entire data set info
data.describe()


def find_outliers_IQR(df):

   q1=df.quantile(0.25)

   q3=df.quantile(0.75)

   IQR=q3-q1

   outliers = df[((df<(q1-1.5*IQR)) | (df>(q3+1.5*IQR)))]

   return outliers

outliers = find_outliers_IQR(data[['Quantity','UnitPrice','CustomerID']])

outliers = find_outliers_IQR(data['Quantity'])


print("number of outliers: "+ str(len(outliers)))
print("max outlier value: "+ str(outliers.max()))
print("min outlier value: "+ str(outliers.min()))


def drop_outliers_IQR(df):

   q1=df.quantile(0.25)

   q3=df.quantile(0.75)

   IQR=q3-q1

   not_outliers = df[~((df<(q1-1.5*IQR)) | (df>(q3+1.5*IQR)))]

   outliers_dropped = outliers.dropna().reset_index()

   return outliers_dropped

outliers_drop = drop_outliers_IQR(data['Quantity'])
outliers_drop = find_outliers_IQR(data[['Quantity','UnitPrice','CustomerID']])
print("number of outliers drop: "+ str(len(outliers_drop)))



data.dropna(axis=0, subset=['CustomerID'], inplace=True)
data.duplicated(subset=None, keep='first')

print('Duplicate data: {}'.format(data.duplicated().sum()))
data.drop_duplicates(inplace = True)

data.to_excel(r'E:\power bi\customer\clean_data.xlsx', index=False)


