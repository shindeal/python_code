 # -*- coding: utf-8 -*-
"""
Created on Wed Feb 16 14:24:40 2022

@author: abc
"""

import pandas as pd
data = pd.read_table("Movie_Review.csv",sep=',')





"""words = nltk.word_tokenize(corpus)
for word in words:
    print("the word is :",word)"""

import nltk
from nltk.tokenize import word_tokenize
reviews = data.review.str.cat(sep=' ')


#function to split text into words
tokens = word_tokenize(reviews)
vocabulary =set(tokens)
print(len(vocabulary))
frequency_dist = nltk.FreqDist(tokens)


sorted(frequency_dist,key=frequency_dist.__getitem__
       ,reverse=True)[0:50]

#Remove stop words
from nltk.corpus import stopwords
stop_words = set(stopwords.words('english'))
filtered_sentence = [w for w in tokens if not w in stop_words]


large_words = dict( [(k,v) for k, v in frequency_dist.items() if len(k)>8] )

frequency_dist1 = nltk.FreqDist(tokens)

from wordcloud import WordCloud
import matplotlib.pyplot as plt


wordcloud = WordCloud(max_font_size=50, max_words=100, background_color="black").generate_from_frequencies(frequency_dist)
plt.figure()
plt.imshow(wordcloud, interpolation="bilinear")
plt.axis("off")
plt.show()


#train-test split
from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test = train_test_split(
    data['review'], data['sentiment'], test_size=0.3, random_state=1
    
    )


from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import TfidfTransformer

vectorizer = TfidfVectorizer(max_features=10000)
train_vectors = vectorizer.fit_transform(x_train)
test_vectors = vectorizer.transform(x_test)
print(train_vectors.shape,test_vectors.shape)


from sklearn.naive_bayes import MultinomialNB
clf= MultinomialNB().fit(train_vectors,y_train)

from sklearn.metrics import accuracy_score
predicted = clf.predict(test_vectors)   
print(accuracy_score(y_test,predicted))

