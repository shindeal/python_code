# -*- coding: utf-8 -*-
"""
Created on Wed Feb  9 14:09:11 2022

@author: abc
"""

import nltk
from nltk.corpus import stopwords

text = """
Signing out of account, Standby... The company announced that it will stop selling its products to Russian citizens who intend to bring them to their country. The move unleashed fury. Many companies have announced the suspension of their operations on Russian territory as a result of the armed conflict against Ukraine. None have elicited such extreme reactions from consumers as Chanel . The luxury products company announced that, in addition to ceasing to operate on Russian territory, it will no longer sell its products to Russian citizens who intend to bring them to their country. This with the aim of complying with the sanctions that the European Union (EU) and Switzerland have imposed on Russia. “The most recent EU and Swiss sanctions include a ban on the 'sale, supply, transfer or export, directly or indirectly, of luxury goods to any natural or legal person, entity or body in Russia or for use in Russia. … We have put in place a process to ask customers whose primary residence we do not know to confirm that the items they are purchasing will not be used in Russia," the company explained in a press release. The sanction applies to products worth more than €300 (about $328 dollars) — most of Chanel's catalog — and some Russian influencers have reported restrictions on being able to buy the brand's products in cities in France and the United Arab Emirates. Joined. The statement was enough to unleash the fury of some influencers who decided to express their rejection of the measure on their social media profiles using the hashtag #byebyechanel . Victoria Bonya , a Russian who lives in Monaco and whose Instagram profile has more than 9.3 million users, uploaded a video in which she tears apart a Chanel bag with scissors after explaining: “If the Chanel house does not respect its customers Why do we have to respect Chanel House? A post shared by VICTORIA BONYA (@victoriabonya) Marina Ermoshkina , influencer and actress, joined the cause denouncing the Russophobia of the French brand with the message: “For us Russian girls, Chanel plays no role in our lives. Not a single bag, not a single thing is worth the love for my country… I am against Russophobia, I am against a brand that supports Russophobia.” The girl who is followed by more than 300 thousand users cut a bag with gardening shears. A post shared by Marina Ermoshkina (@amazing_marina) DJ Katya Guseva told her more than 580,000 followers: “I say 'NO' to Chanel. They are forcing me to sign a document that humiliates me, forcing me to reject my homeland in favor of their brand." Then he takes scissors and destroys a bag. A post shared by Екатерина Гусева (@djkatyaguseva) Although the posts combined have more than 100,000 likes, in the comments there are critical voices that describe their reactions as a tantrum and ask if it would not be better to sell the bags and donate the proceeds to a good cause. What do you think? Exclusive: Tom Brady Appoints Lowe's Executive as the New CEO of His Wellness Company TB12 The Richest Person on Earth Breaks Every Rule, and You Should Too Food Network Star Geoffrey Zakarian Distills the Entire Hospitality Industry Down Into Just 48 Words Overcome the 5 Common Obstacles Keeping You From Full-Time Entrepreneurship How This First-Generation American Founder Is Taking on Fast-Food Giants Want to Improve Your Creativity and Focus? Try Eating Chocolate for Breakfast How the Creator of Dugout Mugs Hit a $30 Million Home Run With a Business He Started in His Apartment Entrepreneur Staff Jason Feifer Deep Patel Copyright © 2022 Entrepreneur Media, Inc. All rights reserved.
Entrepreneur® and its related marks are registered trademarks of Entrepreneur Media Inc. Entrepreneur® and its related marks are registered trademarks of Entrepreneur Media Inc. Entrepreneur® and its related marks are registered trademarks of Entrepreneur Media Inc. Successfully copied link"""


#corpus = open('ObamaSpeech.txt', 'r').read()
corpus =text
corpus = corpus.lower()
    
words = nltk.word_tokenize(corpus)
for word in words:
    #word=word
    print("the word is :",word)
#print("the word is :",len(words))
 

stop_words = set(stopwords.words('english'))
filtered_words =[]

#filtered_word = [w for w in stop_words if not w in stop_words]

for w in words:
    if w not in stop_words:
        filtered_words.append(w)

print('\n With stop words:', words)
print('\n After removing stop words:', filtered_words)



frequency_dist = nltk.FreqDist(filtered_words)

sorted(frequency_dist,key=frequency_dist.__getitem__
       ,reverse=True)[0:28]

large_words = dict( [(k,v) for k, v in frequency_dist.items() if len(k)>8] )

frequency_dist = nltk.FreqDist(large_words)
frequency_dist.plot(30,cumulative=False)

from wordcloud import WordCloud
import matplotlib.pyplot as plt

wordcloud = WordCloud(max_font_size=50, max_words=100, background_color="black").generate_from_frequencies(frequency_dist)
plt.figure()
plt.imshow(wordcloud, interpolation="bilinear")
plt.axis("off")
plt.show()