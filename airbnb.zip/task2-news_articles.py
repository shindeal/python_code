# -*- coding: utf-8 -*-
"""
Created on Wed Apr 13 11:06:04 2022

@author: abc
"""

#Import necessary libraries
import pprint
import requests 
from bs4 import BeautifulSoup
import urllib.request
import webbrowser
from wordcloud import WordCloud
import matplotlib.pyplot as plt
import seaborn as sns
sns.set_theme(style="darkgrid")
import nltk
import string
import pandas as pd

#Import for topic modelling - unsupervised training
import os.path
import os
from gensim import corpora
from gensim.models import LsiModel
from nltk.tokenize import RegexpTokenizer
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
from gensim.models.coherencemodel import CoherenceModel

from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfVectorizer
count_vectorizer = CountVectorizer()


secret = '56f93f8dbb854e74b87ab0b515a922ed'

url = 'https://newsapi.org/v2/everything?'

parameters = {'q': 'Fury', # query phrase
              'pageSize': 20,  # maximum is 100
              'apiKey': secret # your own API key
              }

# Make the request
response = requests.get(url, params=parameters)

# Convert the response to JSON format and pretty print it
response_json = response.json()
pprint.pprint(response_json)

response_dict_={ 'title':[], 'url':[],'publishedAt':[]}

for i in response_json['articles'][0:5]:
        response_dict_['title'].append(i['title'])
        response_dict_['url'].append(i['url'])
        response_dict_['publishedAt'].append(i['publishedAt'])
        
        #a=response_dict_['url'].append(i['url'])
        #a=requests.get(response_dict_['url'].append(i['url']))
        

#final_url=requests.get(new_url)
#final_url_text = final_url.string()
#with open("task2_news.html") as fp:
    #soup = BeautifulSoup(fp, "html.parser")


# link for extract html data 
def getdata(url): 
    r = requests.get(url) 
    return r.text 

#Finding     

htmldata = getdata("https://www.entrepreneur.com/article/424517") 
soup = BeautifulSoup(htmldata, 'html.parser') 
#data = []
#for data in soup.find_all("p"): 
    #print(data.get_text())
    
all_paragraphs = soup.find_all("p")
#print(all_paragraphs[0:3])
    
all_paragraphs_text = [paragraph.text.strip() for paragraph in all_paragraphs]
full_paragraphs = [paragraph for paragraph in all_paragraphs_text if paragraph]

single_paragraphs = ' '.join(map(str,full_paragraphs)).translate(str.maketrans('', '', string.punctuation))
print("Total number of characters in an article :",len(single_paragraphs))

sentences = nltk.sent_tokenize(single_paragraphs)
for i in sentences:
    count=i
print("Total number of sentences in an article :",len(count))
    

words = nltk.word_tokenize(single_paragraphs)
print("Total number of words in an article :",len(words))
for j in words:
    word=j # differts words in a paragrahs
    print("the word is :",word)
 
stop_words = set(stopwords.words('english'))


filtered_word = [w for w in words if not w in stop_words]
filtered_word_str=' '.join(map(str,filtered_word))

print('\n With stop words:', words)
print('\n After removing stop words:', filtered_word)

#world cloud of filtered words
wordcloud = WordCloud(max_font_size=40).generate(filtered_word_str)
plt.figure()
plt.imshow(wordcloud, interpolation="bilinear")
plt.axis("off")
plt.show()

#Finding the frequeny distribution of words
frequency_dist = nltk.FreqDist(filtered_word)

#sorting the FD of words
sorted(frequency_dist,key=frequency_dist.__getitem__
       ,reverse=True)[0:28]

#keeping only the large words more than 8 characters
large_words = dict( [(k,v) for k, v in frequency_dist.items() if len(k)>8] )

#Plotting FD
frequency_dist = nltk.FreqDist(large_words)
frequency_dist.plot(30,cumulative=False,title="Frequency Distribution of same wprds")

#tips = frequency_dist
#sns.relplot(data=tips);

wordcloud = WordCloud(max_font_size=50, max_words=10, background_color="Red").generate_from_frequencies(frequency_dist)
plt.figure()
plt.imshow(wordcloud, interpolation="bilinear")
plt.axis("off")
plt.show()

#Feature Extraction and word embedding
bag_of_words = count_vectorizer.fit_transform(frequency_dist)#full_paragraphs to check what needs to be passed
#frequency_dist

feature_names = count_vectorizer.get_feature_names()
BOW_matrix=pd.DataFrame(bag_of_words.toarray(),columns=feature_names)


tfidr_vectorizer = TfidfVectorizer()
values = tfidr_vectorizer.fit_transform(frequency_dist)

feature_names1=tfidr_vectorizer.get_feature_names()
TFIDF_matrix= pd.DataFrame(values.toarray(),columns=feature_names1)


####code for multiple articles#
urls = ['http://understandingdata.com/', 'https://understandingdata.com/about-me/', 'https://understandingdata.com/contact/']

results = []
for url in urls:
   # 2. Obtain the HTML response:
   response = requests.get(url)
   # 3. Create a BeautifulSoup object:
   soup = BeautifulSoup(response.content, 'html.parser')
   # 4. Extract the elements per URL:
   title_tag = soup.title
   results.append(title_tag.text)
###############end##########################3
    
#showing world cloud of 5 articles title for a particular trend #Fury
text_combined = ''
for i in response_json['articles']:
    text_combined += i['title'] + ' '
    
print(text_combined[0:30])

wordcloud = WordCloud(max_font_size=40).generate(text_combined)
plt.figure()
plt.imshow(wordcloud, interpolation="bilinear")
plt.axis("off")
plt.show()

#*********************topic Modelling******************

def preprocess_data(doc_set):
    tokenizer = RegexpTokenizer(r'\w+')
    en_stop= set(stopwords.words('english'))
    p_stemmer= PorterStemmer()
    texts = []
    
    
    for i in doc_set:
        raw = i.lower()
        tokens = tokenizer.tokenize(raw)
        
        stopped_tokens = [i for i in tokens if not i in en_stop ]
        stemmed_tokens = [p_stemmer.stem(i) for i in stopped_tokens]
        texts.append(stemmed_tokens)
    return texts  
    


def prepare_corpus(doc_clean):
    dictionary=corpora.Dictionary(doc_clean)
    doc_term_matrix=[dictionary.doc2bow(doc) for doc in doc_clean]
    #print(dictionary,doc_term_matrix)
    return dictionary,doc_term_matrix
    


def create_gensim_lsa_model(doc_clean,number_of_topics,words):
    dictionary,doc_term_matrix=prepare_corpus(doc_clean)
    lsamodel= LsiModel(doc_term_matrix,num_topics=number_of_topics,id2word=dictionary)
    print(lsamodel.print_topics(num_topics=number_of_topics,num_words=words))
    return lsamodel


number_of_topics= 3
words=2
#documents_list,titles= load_data("","articles.csv")
documents_list= full_paragraphs
print("Total number of Documents: ", len(documents_list))
clean_text=preprocess_data(documents_list)
model= create_gensim_lsa_model(clean_text,number_of_topics,words)
    
