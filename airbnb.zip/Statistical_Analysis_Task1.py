# -*- coding: utf-8 -*-
"""
Created on Mon Mar 28 18:34:02 2022

@author: abc
"""

from twython import Twython
import json
import pandas as pd
import matplotlib.pyplot as plt
import regex
from matplotlib import dates as mpl_dates
from datetime import datetime, timedelta

with open("twitter_credentials.json","r") as file:
     creds=json.load(file)   
     
python_tweets = Twython(creds['CONSUMER_KEY'],creds['CONSUMER_SECRET'])

#Popular trends in the UK
trends = Twython.get_place_trends(python_tweets,id=23424975 )

dict_={ 'Name':[], 'Tweet_Count':[]}

for value in trends:
    for trend in value['trends']:
        dict_['Name'].append(trend['name'])
        dict_['Tweet_Count'].append(trend['tweet_volume'])
        
        df = pd.DataFrame(dict_)
        df['Tweet_Count']=df['Tweet_Count'].fillna(0)
        df1 = df.loc[df['Tweet_Count'] > 0.0]
        
# =============================================================================
df1.plot.bar(x="Name", y="Tweet_Count", color=['Blue', 'red', 'green', 'orange', 'cyan'], title="Top Trends and Tweet Volume in the UK",ylabel='The Volume of tweet generated',xlabel='Trend Name');
current_values = plt.gca().get_yticks()
plt.gca().set_yticklabels(['{:.0f}'.format(x) for x in current_values])
# =============================================================================


################################part2#####################################
query = {'q':'Lady Gaga',
        'result_type':'trend',
        'count':500,
        'lang':'en'
        }

sample_return = python_tweets.search(**query)
dict_={  'created_at':[], 'source':[],'verified':[],'user':[]}

for status in python_tweets.search(**query)['statuses']:
    dict_['created_at'].append(status['created_at'])
    dict_['source'].append(status['source'])
    dict_['user'].append(status['user'])
    dict_['verified'].append(status['user']['verified'])
    
df2 = pd.DataFrame(dict_)
df2['new_source']= df2['source'].str.extract('>(.+?)<') #extracting the source

df3=df2.groupby(['new_source']).size().reset_index(name='Total_Count')
df3.plot.bar( x="new_source", y="Total_Count",color=['Blue', 'red', 'green'],title='Devices Used for Trend',xlabel='Devices',ylabel='No. of devices used')

###################################part3 this is for devices/count#########################################

my_labels=df3.new_source
df3.plot.pie(labels = my_labels,y="Total_Count",autopct='%1.1f%%', figsize=(8,7)) 
plt.title("Percentage distribution of Various devices")
plt.legend(my_labels, loc="best", fontsize=7)

######################part4 this is for verified###########################

df4=df2.groupby(['verified']).size().reset_index(name='Total_Count')
my_labels=df4.verified

df4.plot.pie(labels = my_labels,y="Total_Count",autopct='%1.1f%%')
plt.title("Percentage distribution of Verified and Unverified Users")
plt.legend(my_labels, loc="best", fontsize=4)

#######################part5 time series############################
# =============================================================================
# 
# dict_['created_at'] = pd.to_datetime(dict_['created_at'],utc=True)
# df2['created_at'] = pd.to_datetime(df2['created_at'])
# plt.plot(dict_['created_at'])
# plt.title("Time series for trend #")
# plt.show()
# =============================================================================
