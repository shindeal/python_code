# -*- coding: utf-8 -*-
"""
Created on Wed Feb 16 16:36:35 2022

@author: abc
"""



from textblob import TextBlob
import nltk
wiki = TextBlob("Python is a high-level, general-purpose programming language.")
part_of_speech = wiki.tags

testimonial = TextBlob("Congratulations Minseok, Junmyeon, Yixing, Baekhyun, Jongdae, Chanyeol, Kyungsoo, Jongin, and Sehun! As K-Pop legen… https://t.co/Am5AETiOz4")
print(testimonial.sentiment)
print(testimonial.sentiment.polarity)

if testimonial.sentiment.polarity > 0:
        print('positive')
elif testimonial.sentiment.polarity == 0:
    print( 'neutral')
else:
    print( 'negative')
  