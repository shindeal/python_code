# -*- coding: utf-8 -*-
"""
Created on Tue Mar 22 19:12:32 2022

@author: abc
"""

from twython import Twython
import matplotlib as plt
import json
import pandas as pd


with open("twitter_credentials.json","r") as file:
    creds=json.load(file)
    
    
python_tweets = Twython(creds['CONSUMER_KEY'],creds['CONSUMER_SECRET'])




if __name__ == "__main__":
    # Available Locations
    available_trends = Twython.get_place_trends(python_tweets,id=23424975) #UK
    with open("available_locations_for_trend.json","w") as wp:
         wp.write(json.dumps(available_trends, indent=1))


