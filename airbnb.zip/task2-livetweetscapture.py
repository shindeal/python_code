# -*- coding: utf-8 -*-
"""
Created on Tue Apr 12 13:57:14 2022

@author: abc
"""

from twython import TwythonStreamer
import csv

def process_tweet(tweet):
    d={}
    d['hashtags']=[hashtag['text']for hashtag in tweet['entities']['hashtags']]
    d['text']=tweet['text']
    d['user']=tweet['user']['screen_name']
    d['user_loc']=tweet['user']['location']
    return d

class MyStreamer(TwythonStreamer):

    def on_success(self,data):
        if data['lang']=='en':
            tweet_data=process_tweet(data)
            self.save_to_csv(tweet_data)

    def on_error(self, status_code,data):
        print(status_code,data)
        self.disconnect()

    def save_to_csv(self,tweet):
        with open(r'saved_tweets.csv','w',encoding='utf-8')as file:
           writer=csv.writer(file)
           writer.writerow(list(tweet.values()))
       
       
import json
with open("twitter_credentials.json","r") as file:
    creds=json.load(file)
    
stream = MyStreamer(creds['CONSUMER_KEY'],creds['CONSUMER_SECRET'],
    creds['ACCESS_TOKEN'],creds['ACCESS_SECRET'])

stream.statuses.filter(track='saudis')
