# -*- coding: utf-8 -*-
"""
Created on Wed Feb 23 15:28:02 2022

@author: abc
"""

import networkx as nx
import matplotlib.pyplot as plt

G_fb = nx.read_edgelist("facebook_combined.txt", create_using = nx.Graph(), nodetype=int)

pos = nx.spring_layout(G_fb)
#betCent = nx.betweenness_centrality(G_fb, normalized=True, endpoints=True)
#deg = nx.degree_centrality(G_fb)
eig = nx.eigenvector_centrality(G_fb)
sorted(eig, key=eig.get, reverse=True)[:5]

print(nx.info(G_fb))

node_color=[20000.0 * G_fb.degree(v) for v in G_fb]
node_size = [v*10000 for v in eig.values(   )]
plt.figure(figsize=(20,20))
nx.draw_networkx(G_fb,pos=pos,with_labels=False,
                 node_color=node_color,
                 node_size=node_size
                 )



#deg = nx.Degree_centrality(G_fb, normalized=True, endpoints=True)
#eig = nx.eigenvector_centrality(G_fb, normalized=True, endpoints=True)

