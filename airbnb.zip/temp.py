
from PIL import Image
from pytesseract import pytesseract
import os
from os import listdir
  

def main():
    path_to_tesseract = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

    pytesseract.tesseract_cmd = path_to_tesseract

    files = os.listdir(r'E:\Dessertation\Final_Images')
    combine_string=''
    i = 0
    while i in range(len(files)):
    #print(files[i])
        img = Image.open(os.path.join(r'E:\Dessertation\Final_Images', files[i]))
        text = pytesseract.image_to_string(img)
        combine_string= combine_string+text
        i=i+1
        print(combine_string[:-1])
        
if __name__ == '__main__':
    main()
    

    
    
  



        
    