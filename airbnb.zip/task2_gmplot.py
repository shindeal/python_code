import geopy
import gmplot 

import webbrowser
import numpy as np



from geopy.geocoders import Nominatim
geolocator = Nominatim(user_agent="my_user_agent")

country ="Strasbourg"
loc = geolocator.geocode(country)
print("latitude is :-" ,loc.latitude,"\nlongtitude is:-" ,loc.longitude)

lat= loc.latitude
lon= loc.longitude
tower = gmplot.GoogleMapPlotter(0, 0, 13 )
tower.text(lat, lon, 'Rihanna Popular Location', color='blue')


tower.heatmap(lat, lon)
tower.draw( "C:/Users/abc/.spyder-py3/map.html" ) 
webbrowser.open_new_tab("C:/Users/abc/.spyder-py3/map.html")



