# -*- coding: utf-8 -*-
"""
Created on Wed Apr  6 14:46:18 2022

@author: abc
"""

from bs4 import BeautifulSoup

with open("With Peloton Guide, the Fitness Company Bets Big on Body Tracking _ WIRED.html", encoding="utf8") as fp:
    soup = BeautifulSoup(fp, "html.parser")
    

print(soup.head.title)
print(soup.body.a.text)
print(soup.body.p.b)


print(soup.find_all("a"))

soup.find_all("a", class_="element")

