# -*- coding: utf-8 -*-
"""
Created on Wed Feb 23 15:15:19 2022

@author: abc
"""


import networkx as nx
import matplotlib.pyplot as plt

#We read in the file and construct the Graph:
G_fb = nx.read_edgelist("facebook_combined.txt", create_using = nx.Graph(), nodetype=int)

print(nx.info(G_fb))
#print(G_fb[1])


plt.figure(figsize=(20,20))
color_map = []
for node in G_fb:
    if node < 2000:
        color_map.append('blue')
    else: 
        color_map.append('green')      
nx.draw_networkx(G_fb, node_color=color_map, with_labels=False)


pos = nx.spring_layout(G_fb)
sorted(pos, key=pos.get, reverse=True)[:5]
print(nx.info(G_fb))
node_color=[20000.0 * pos.degree(v) for v in G_fb]
node_size = [v*10000 for v in pos.values(   )]
plt.figure(figsize=(20,20))
nx.draw_networkx(G_fb,pos=pos,with_labels=False, node_color=node_color,node_size=node_size
                 )

