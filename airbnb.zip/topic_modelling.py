# -*- coding: utf-8 -*-
"""
Created on Wed Mar  9 14:04:04 2022

@author: abc
"""

import os.path
import os
from gensim import corpora
from gensim.models import LsiModel
from nltk.tokenize import RegexpTokenizer
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
from gensim.models.coherencemodel import CoherenceModel
import matplotlib.pyplot as plt

#path ='C:/Users/abc/.spyder-py3'
#file_name='articles.csv'

def load_data(path,file_name):
    documents_list = []
    titles=[]
    with open(os.path.join(path,file_name),'r',encoding="utf8") as fin:
         for line in fin.readlines():
             text=line.strip()
             documents_list.append(text)
    print("Total number of Documents: ", len(documents_list))
    titles.append(text[0:min(len(text),100)])
    return documents_list,titles



def preprocess_data(doc_set):
    tokenizer = RegexpTokenizer(r'\w+')
    en_stop= set(stopwords.words('english'))
    p_stemmer= PorterStemmer()
    texts = []
    
    for i in doc_set:
        raw = i.lower()
        tokens = tokenizer.tokenize(raw)
        
        stopped_tokens = [i for i in tokens if not i in en_stop ]
        stemmed_tokens = [p_stemmer.stem(i) for i in stopped_tokens]
        texts.append(stemmed_tokens)
    return texts    


def prepare_corpus(doc_clean):
    dictionary=corpora.Dictionary(doc_clean)
    doc_term_matrix=[dictionary.doc2bow(doc) for doc in doc_clean]
    return dictionary,doc_term_matrix


def create_gensim_lsa_model(doc_clean,number_of_topics,words):
    dictionary,doc_term_matrix=prepare_corpus(doc_clean)
    lsamodel= LsiModel(doc_term_matrix,num_topics=number_of_topics,id2word=dictionary)
    print(lsamodel.print_topics(num_topics=number_of_topics,num_words=words))
    return lsamodel

number_of_topics= 7
words=10
documents_list,titles=load_data("","articles.csv")
clean_text=preprocess_data(documents_list)
model= create_gensim_lsa_model(clean_text,number_of_topics,words)
    