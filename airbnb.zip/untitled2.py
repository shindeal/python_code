# -*- coding: utf-8 -*-
"""
Created on Wed Jan 26 15:49:11 2022

@author: abc
"""

import math
print(math.pow(2, 2))