# -*- coding: utf-8 -*-
"""
Created on Thu Dec  1 10:57:21 2022

@author: abc
"""

import pandas as pd

df=['Natural Language Processing is a part of AI',
    'Machine learning is a part of AI', 
    ]

df=['Natural Language Processing is a subfield of AI',
    'Computer Vision is a subfield of AI']
df1= pd.DataFrame(df,columns=['text'])

from sklearn.feature_extraction.text import CountVectorizer

cv= CountVectorizer()
bow= cv.fit_transform(df1['text'])

print(sorted(cv.vocabulary_))
print(bow.toarray())


cv1= CountVectorizer(ngram_range=(1,2))
bow1= cv1.fit_transform(df1['text'])

print(sorted(cv1.vocabulary_))
print(bow1.toarray())

cv2= CountVectorizer(ngram_range=(2,2))
bow2= cv2.fit_transform(df1['text'])

print(sorted(cv2.vocabulary_))
print(bow2.toarray())


from sklearn.feature_extraction.text import TfidfVectorizer
tfidf= TfidfVectorizer()

tfvector= tfidf.fit_transform(df1['text'])

print(sorted(tfidf.vocabulary_))
print(tfvector.toarray())
