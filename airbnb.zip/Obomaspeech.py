# -*- coding: utf-8 -*-
"""
Created on Wed Feb  2 14:55:54 2022

@author: abc
"""

import nltk

corpus = open('ObamaSpeech.txt', 'r').read()

sentences1 = nltk.sent_tokenize(corpus)

for sentence in sentences1:
    print("Printing sentence is :",sentence)
    
words = nltk.word_tokenize(sentences1[0])
for word in words:
    print("the word is :",word)
 
import nltk
from nltk.corpus import stopwords
print(stopwords.words('English'))

from nltk.tokenize import word_tokenize

example_sent = """Our Constitution declares that from time to time, the President shall give to Congress information about the state of our Union. For 220 years, our leaders have fulfilled this duty. They've done so during periods of prosperity and tranquility, and they've done so in the midst of war and depression, at moments of great strife and great struggle."""

stop_words = set(stopwords.words('english'))

word_tokens = word_tokenize(example_sent)


filtered_sentence = [w for w in word_tokens if not w in stop_words]

print('\n With stop words:', word_tokens)
print('\n After removing stop words:', filtered_sentence)

from nltk.stem import PorterStemmer, WordNetLemmatizer

from nltk.corpus import wordnet

lemmatizer = WordNetLemmatizer()
stemmer = PorterStemmer()

word = 'Constitution'

print('the lemma of the word is :',lemmatizer.lemmatize(word,pos=wordnet.VERB))
print('The stem of word is:',stemmer.stem(word))

#frequency_dist = nltk.FreqDist(list_of_words)