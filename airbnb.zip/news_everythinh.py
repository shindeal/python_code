# -*- coding: utf-8 -*-
"""
Created on Wed Apr  6 14:16:59 2022

@author: abc
"""


import pprint
import requests     # 2.19.1


secret = '56f93f8dbb854e74b87ab0b515a922ed'

url = 'https://newsapi.org/v2/everything?'

parameters = {
    'q': 'big data', # query phrase
    'pageSize': 20,  # maximum is 100
    'apiKey': secret # your own API key
}


response = requests.get(url, params=parameters)

response_json = response.json()
pprint.pprint(response_json)



