# -*- coding: utf-8 -*-
"""
Created on Wed Feb 23 14:16:46 2022

@author: abc
"""

import networkx as nx

WeightedG = nx.Graph()

WeightedG.add_edge('Coventry','Dudley', weight=33)
WeightedG.add_edge('Birmingham','Wolverhampton', weight=17)
WeightedG.add_edge('Birmingham','Dudley', weight=22)
WeightedG.add_edge('Wolverhampton','Dudley', weight=6)
WeightedG.add_edge('Birmingham','Dudley', weight=9)
WeightedG.add_edge('Coventry','Wolverhampton', weight=34)
WeightedG.add_edge('Coventry','Birmingham', weight=9)
WeightedG.add_edge('mumbai','Birmingham', weight=2)

pos = nx.spring_layout(WeightedG)

nx.draw_networkx_nodes(WeightedG, pos, node_color='g', alpha=0.8)
nx.draw_networkx_edges(WeightedG, pos, edge_color='b', alpha=0.8)
nx.draw_networkx_edge_labels(WeightedG, pos, edge_labels=nx.get_edge_attributes(WeightedG, 'weight'))
nx.draw_networkx_labels(WeightedG, pos)

print(nx.shortest_path(WeightedG,'Coventry', 'Birmingham'))
print(nx.shortest_path_length(WeightedG,'Coventry', 'Birmingham'))
print(nx.average_shortest_path_length(WeightedG))
print(nx.eccentricity(WeightedG,'Coventry'))
print(nx.eccentricity(WeightedG,'birmingham'))

print(nx.eccentricity(WeightedG))
print(nx.degree_centrality(WeightedG))