# -*- coding: utf-8 -*-
"""
Created on Wed Mar  2 15:01:45 2022

@author: abc
"""

import json

credentials = {}

"""credentials['CONSUMER_KEY']= 'OZ16zAjrmUHoaKD7sro3bEkgt'
credentials['CONSUMER_SECRET']='ZAHKUsk3Ixx9O6MyP7zuC8R6vRVcUmx0t0iPgCDP0rvGmoxmz9'
credentials['ACCESS_TOKEN']='1490720870637223941-vwbjngdxd8xsPSsGsdL1PjlOP5VJRT'
credentials['ACCESS_SECRET']='YtZSaN6TsYaRjQdbgKU3pDolpk0AExmzm4dtPlNFD8OBJ'"""


credentials['CONSUMER_KEY'] = 'YP9n8jk9Al03bYlzRDw74V7OZ'
credentials['CONSUMER_SECRET'] = 'ouXfZXOL7AbTejUYL7KWLqMMvn1nDubqzsycfahVfWkHs6GtdD'
credentials['ACCESS_TOKEN'] = '1502542662959779844-61JpsPY2xec56B8k8NheRyCCnF0JI2'
credentials['ACCESS_SECRET'] = 'c3kCpJVqW87tJwc51sqBxDkH34ssP87kPTgiLhrXOJ6YO'

with open("twitter_credentials.json","w") as file:
    json.dump(credentials,file)