# -*- coding: utf-8 -*-
"""
Created on Wed Jan 26 15:21:39 2022

@author: abc
"""

def bmi_calc(w,h):
    bmi= float(round(w/(h*h),1))
    print("your bmi is",bmi)
    return bmi
    

def input_details():
    w=int(input("Enter the weight:"))
    h=int(input("Entere the height:"))
    value=bmi_calc(w,h)
    print(type(value))
    print("your bmi is",value)
    
    
    if value < 18.5:
       print("your underweight")
    elif value < 18.5 and value <24.5:
        print("your healthy")
    elif value < 25.0 and value <29.9:
        print("your owerweight")
    else:
        print("Obese")
 
    
    
