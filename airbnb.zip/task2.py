# -*- coding: utf-8 -*-
"""
Created on Mon Apr 11 17:45:03 2022

@author: abc
"""

# utilities
import re
import numpy as np
import pandas as pd
from twython import Twython
import json
from textblob import TextBlob
import nltk


# plotting
import seaborn as sns
from wordcloud import WordCloud
import matplotlib.pyplot as plt

# nltk
from nltk.stem import WordNetLemmatizer


# importing twitter credentilas
with open("twitter_credentials.json","r") as file:
        creds=json.load(file)
#python_tweets = Twython(creds['CONSUMER_KEY'],creds['CONSUMER_SECRET'])

#search query to extract the popular tweet 
#query = {'q':'sehun','result_type':'popular','count':100,'lang':'en'}

#sample_return = python_tweets.search(**query)

#dict_={ 'user':[], 'date':[], 'text':[], 'favorite_count':[] }
# =============================================================================
# for status in python_tweets.search(**query)['statuses']:
#     dict_['user'].append(status['user']['screen_name'])
#     dict_['date'].append(status['created_at'])
#     dict_['text'].append(status['text'])
#     dict_['favorite_count'].append(status['favorite_count'])
# =============================================================================
       
# =============================================================================
#     
#df = pd.DataFrame(dict_['text'],columns=['Text'])
#tweet_text = df['Text'].values
#tweet_string= str(tweet_text)


#Sentences= nltk.sent_tokenize(tweet_string)
#length= len(Sentences)


# for i in df.Text[0:length]:
#     blob = TextBlob(i)
#     if blob.sentiment.polarity > 0:
#         print('positive')
#     elif blob.sentiment.polarity == 0:
#         print( 'neutral')
#     else:
#         print( 'negative')
#   
# =============================================================================
    
data = pd.read_table("live_tweets.csv",sep=',')
leng = len(data)

tweet_list = []
sentiment_list=[]

for i in data.Tweets[0:100]:
    tweet_list.append(i)
    blob = TextBlob(i)
    if blob.sentiment.polarity > 0:
       # print('positive')
        sentiment_list.append('positive')
    elif blob.sentiment.polarity == 0:
        #print('neutral')
        sentiment_list.append('neutral')
    else:
        #print('negative')
        sentiment_list.append('negative')
        
   
df_final=pd.DataFrame(columns=['Tweets','Sentiments'])
df_final['Tweets'],df_final['Sentiments']=tweet_list,sentiment_list
      

import seaborn as sns
sns.countplot(x='Sentiments', data=df_final)          
        
import nltk
from nltk.tokenize import word_tokenize
tweets = data.Tweets.str.cat(sep=' ')    

#function to split text into words
tokens = word_tokenize(tweets)
vocabulary =set(tokens)
print(len(vocabulary))
frequency_dist = nltk.FreqDist(tokens)

sorted(frequency_dist,key=frequency_dist.__getitem__,reverse=True)[0:50]

#Remove stop words
from nltk.corpus import stopwords
stop_words = set(stopwords.words('english'))
filtered_sentence = [w for w in tokens if not w in stop_words]


large_words = dict( [(k,v) for k, v in frequency_dist.items() if len(k)>8] )

frequency_dist1 = nltk.FreqDist(tokens)

from wordcloud import WordCloud
import matplotlib.pyplot as plt


wordcloud = WordCloud(max_font_size=50, max_words=100, background_color="black").generate_from_frequencies(frequency_dist)
plt.figure()
plt.imshow(wordcloud, interpolation="bilinear")
plt.axis("off")
plt.show()


#train-test split
from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test = train_test_split(
    df_final['Tweets'], df_final['Sentiments'], test_size=0.3, random_state=1)

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import TfidfTransformer

vectorizer = TfidfVectorizer(max_features=10000)
train_vectors = vectorizer.fit_transform(x_train)
test_vectors = vectorizer.transform(x_test)
print(train_vectors.shape,test_vectors.shape)


from sklearn.naive_bayes import MultinomialNB
clf= MultinomialNB().fit(train_vectors,y_train)

from sklearn.metrics import accuracy_score
predicted = clf.predict(test_vectors)   
print(accuracy_score(y_test,predicted))