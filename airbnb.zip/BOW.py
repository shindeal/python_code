# -*- coding: utf-8 -*-
"""
Created on Wed Feb  9 15:14:15 2022

@author: abc
"""

with open("HotelReviews.txt","r") as file:
     documents = file.read().splitlines()
     
with open("ObamaSpeech_bow.txt","r") as file:
     documents_ob = file.read().splitlines()   
    
print(documents)
print(documents_ob)

#import the required libraries
from sklearn.feature_extraction.text import CountVectorizer

#Design the vocabulary
count_vectorizer = CountVectorizer()

import pandas as pd

bag_of_words = count_vectorizer.fit_transform(documents)

bag_of_words_ob = count_vectorizer.fit_transform(documents_ob)

feature_names = count_vectorizer.get_feature_names()
print(pd.DataFrame(bag_of_words.toarray(),columns=feature_names))

print(pd.DataFrame(bag_of_words_ob.toarray(),columns=feature_names))


from sklearn.feature_extraction.text import TfidfVectorizer
import pandas as pd


tfidr_vectorizer = TfidfVectorizer()
values = tfidr_vectorizer.fit_transform(documents)

feature_names1=tfidr_vectorizer.get_feature_names()
TFIDF_matrix= pd.DataFrame(values.toarray(),columns=feature_names1)
