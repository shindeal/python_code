
    
from twython import Twython
import json
    # =============================================================================
    # import seaborn as sns
    # plt.style.use('seaborn')
    # =============================================================================
import pandas as pd
import matplotlib.pyplot as plt
    
    #from matplotlib.ticker import StrMethodFormatter
import regex
    
    
from matplotlib import dates as mpl_dates
from datetime import datetime, timedelta
    
    
    
    
    
with open("twitter_credentials.json","r") as file:
        creds=json.load(file)
        
    
python_tweets = Twython(creds['CONSUMER_KEY'],creds['CONSUMER_SECRET'])
    
trends = Twython.get_place_trends(python_tweets,id=23424975 )
    
    
dict_={ 'Name':[], 'Tweet_Count':[]}
    
    
for value in trends:
        for trend in value['trends']:
            dict_['Name'].append(trend['name'])
            dict_['Tweet_Count'].append(trend['tweet_volume'])
    
df = pd.DataFrame(dict_)
df['Tweet_Count']=df['Tweet_Count'].fillna(0)
df1 = df.loc[df['Tweet_Count'] > 0.0]
    
    # =============================================================================
    # 
    #df1.plot.bar(x="Name", y="Tweet_Count", color=['Blue', 'red', 'green', 'orange', 'cyan'], title="Top Trends and Tweet Volume in the UK",ylabel='Volume of tweet generated',xlabel='Trend Name');
    #current_values = plt.gca().get_yticks()
   # plt.gca().set_yticklabels(['{:.0f}'.format(x) for x in current_values])
    # 
    # =============================================================================
    
    
    
    
query = {'q':'Will Smith',
            'result_type':'trend',
            'count':500,
            'lang':'en'
            }
    
sample_return = python_tweets.search(**query)
    
import pandas as pd
    
dict_={  'created_at':[], 'source':[],'verified':[],'user':[]}
    
for status in python_tweets.search(**query)['statuses']:
        dict_['created_at'].append(status['created_at']) #Wed Mar 23 03:25:07 +0000 2022
        dict_['source'].append(status['source'])
        dict_['user'].append(status['user'])
        dict_['verified'].append(status['user']['verified'])
    
    
        
        
df2 = pd.DataFrame(dict_)
df2['new_source']= df2['source'].str.extract('>(.+?)<') #extracting the source
    
    
    
    
    #Wed Mar 23 13:11:25 +0000 2022
    #df2['created_at']= df2['created_at'].str.extract('\((\d{4}-\d{2}-\d{2})\)')[0]
    # =============================================================================
    # 
df3=df2.groupby(['new_source']).size().reset_index(name='Total_Count')
    # df4=df2.groupby(['verified']).size().reset_index(name='Total_Count')
    # 
df3.plot.bar( x="new_source", y="Total_Count",color=['Blue', 'red', 'green'],title='Devices Used for #Oscar', xlabel='Devices',ylabel='No. of devices used')
    # =============================================================================
    
    #df4 = pd.to_datetime(df2['created_at'], format='day%MM%YYYY')
    
    #df2.plot.bar( x="created_at", y="source", title='Volume of Devices used for trends')
    
    
    #df3.groupby(['new_source'])['Total_Count'].count().plot.pie(figsize=(5,5),autopct='%1.1f%%')
    
    #this is for devices/count
    # =============================================================================
   # my_labels=df3.new_source
    #df3.plot.pie(labels = my_labels,y="Total_Count",autopct='%1.1f%%', figsize=(8,7)) #final one
   # plt.legend(my_labels, loc="best", fontsize=7)
    # =============================================================================
    
    
    #this is for verified
    # =============================================================================
    # my_labels=df4.verified
    # df4.plot.pie(labels = my_labels,y="Total_Count",autopct='%1.1f%%') #--final ome
    # plt.legend(my_labels, loc="Best", fontsize=4)
    # 
    # =============================================================================
    
    #x="new_source"
    
    
    #df2.plot.bar(x="count", y="new_source", rot=70, title="Devices used for");
    #sns.barplot(x='user',y='source',data=df)
    
    #df2['created_at']= df2['created_at'].str.extract('(^[a-zA-Z]+)([ ])([a-zA-Z]+)([ ])([0-9])+([ ])([0-9])+[(:)]([0-9])+[(:)]([0-9])+')
    
    
df2['created_at'] = pd.to_datetime(df2['created_at'])
    #df2['created_at'] = df2['created_at'].dt.time
    
    
    # =============================================================================
    # Time=df2['created_at']
    # user =df2['user']
    # =============================================================================
    
    # =============================================================================
    # 
#dict_['created_at'] = pd.to_datetime(dict_['created_at'],utc=True)
plt.plot(dict_['created_at'])
plt.title("Time series for the most popular trend in the UK")
plt.ylabel("Time")
plt.show()
    #  
    # =============================================================================
    
    
    
    
    
    
    
    
    ###################
    
    
    ####################
    
    
    
    
    #df5=df2.groupby(['created_at','new_source']).size().reset_index(name='Count')
    
    
    
    
    #df2.plot.bar(x="created_at", y="user", title="Top Trends and Tweet Volume in the UK");
    
    
    #df2.plot.bar(x="new_source", y="created_at", rot=70, title="Top Trends and Tweet Volume in the UK")
    
    
    
    # =============================================================================
    # 
    # plt.plot(Time, user, color='red', marker='o')
    # plt.title('Source Vs Started each place', fontsize=14)
    # plt.xlabel('Started Each place', fontsize=14)
    # plt.ylabel('Source', fontsize=2)
    # plt.grid(True)
    # plt.show()
    # =============================================================================
    
