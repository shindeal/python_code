# -*- coding: utf-8 -*-
"""
Created on Mon May 15 15:43:43 2023

@author: abc
"""

import pandas as pd
import numpy as np
import csv
import plotly.express as px

data = pd.read_csv("E:\power bi\customer\Airbnb.csv", 
                   encoding="ISO-8859-1",error_bad_lines=False)


data.head()

data.isnull().sum()

print(data.isnull().sum() * 100 / len(data))

data.info()
data.describe()

def find_outliers_IQR(df):
    q1=df.quantile(0.25)
    q3=df.quantile(0.75)
    IQR=q3-q1
    outliers = df[((df<(q1-1.5*IQR)) | (df>(q3+1.5*IQR)))]
    return outliers

outliers = find_outliers_IQR(data['Review Scores Rating'])
print("number of outliers: "+ str(len(outliers)))
print("max outlier value: "+ str(outliers.max()))
print("min outlier value: "+ str(outliers.min()))


def drop_outliers_IQR(df):
    q1=df.quantile(0.25)
    q3=df.quantile(0.75)
    IQR=q3-q1
    not_outliers = df[~((df<(q1-1.5*IQR)) | (df>(q3+1.5*IQR)))]
    outliers_dropped = outliers.dropna().reset_index()
    return outliers_dropped

outliers_drop = drop_outliers_IQR(data['Review Scores Rating'])
print("number of outliers drop: "+ str(len(outliers_drop)))

data.dropna(axis=0, subset=['Review Scores Rating'], inplace=True)
print('Duplicate data: {}'.format(data.duplicated().sum()))
data.drop_duplicates(inplace = True)

data.dropna(inplace=True)

data.to_excel(r'E:\power bi\customer\airbnb_clean_data.xlsx', index=False)