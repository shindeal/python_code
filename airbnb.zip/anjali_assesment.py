

import tweepy
import os
import json
import sys
import geocoder
import matplotlib.pyplot as plt
from twython import Twython
import seaborn as sns


with open("twitter_credentials.json","r") as file:
    creds=json.load(file)
    

# Authorization and Authentication
auth = tweepy.OAuthHandler(creds['CONSUMER_KEY'],creds['CONSUMER_SECRET'])
auth.set_access_token(creds['ACCESS_TOKEN'],creds['ACCESS_SECRET'])
api = tweepy.API(auth)


woeid = 23424975 

trends = api.get_place_trends(id = woeid)



print("The top trends for the location are :")
 
for value in trends:
    for trend in value['trends']:
        print('Name:',trend['name'],'Count:',trend['tweet_volume'])
        
        
import pandas as pd

dict_={ 'Name':[], 'Tweet_Count':[]}


for value in trends:
    for trend in value['trends']:
        dict_['Name'].append(trend['name'])
        dict_['Tweet_Count'].append(trend['tweet_volume'])

df = pd.DataFrame(dict_)
df['Tweet_Count']=df['Tweet_Count'].fillna(0)
df1 = df.loc[df['Tweet_Count'] > 0.0]


#print(df.head(5))


#df1.plot.bar(x="Name", y="Tweet_Count", rot=70, title="Top Trends and Tweet Volume in the UK");

#plt.show(block=True);


sns.barplot(x='Name',y='Tweet_Count',data=df1,palette='spring_r')

