# -*- coding: utf-8 -*-
"""
Created on Wed Feb 23 13:54:24 2022

@author: abc
"""

import networkx as nx

#Indirected Graph

UndirectG = nx.Graph()
UndirectG.add_edge('1','2')
UndirectG.add_edge('1','3')
UndirectG.add_edge('1','4')
UndirectG.add_edge('2','4')
UndirectG.add_edge('2','5')
UndirectG.add_edge('3','4')
UndirectG.add_edge('4','5')

nx.draw_networkx(UndirectG)

#directed graph

directG = nx.DiGraph()
directG.add_edge('1','2')
directG.add_edge('1','3')
directG.add_edge('1','4')
directG.add_edge('2','4')
directG.add_edge('2','5')
directG.add_edge('3','4')
directG.add_edge('4','5')

nx.draw_networkx(directG)

print('The list of all nodes:', list(UndirectG.nodes))
print('The list of all edges:', list(UndirectG.edges))
print('Neighbors of node 1:', list(UndirectG.adj['1']))
print('The degree of node 1:', UndirectG.degree['1'])
print('The degree of node 2:', UndirectG.degree['2'])
