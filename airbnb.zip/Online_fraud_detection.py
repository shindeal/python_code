# -*- coding: utf-8 -*-
"""
Created on Thu Sep  8 11:01:06 2022

@author: abc
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import plotly.express as px
import seaborn as sns

data = pd.read_csv("E:\DA-Project\Online Payments Fraud Detection\PS_20174392719_1491204439457_log.csv")
print(data.head())
print(data.isnull().sum())


print(data.type.value_counts()) #calculates unique values for each type

type = data["type"].value_counts()
df=pd.DataFrame()
df["transaction"] = type.index
df["quantity"] = type.values

my_labels=df.transaction
df.plot.pie(labels = my_labels,y="quantity",autopct='%1.1f%%', figsize=(7,7)) 
plt.title("Percentage distribution of Transaction Types")
plt.legend(my_labels, loc="best", fontsize=6)


# Checking correlation
correlation = data.corr()
print(correlation["isFraud"].sort_values(ascending=False))

sns.heatmap(correlation, annot = True)
plt.show()



data["type"] = data["type"].map({"CASH_OUT": 1, "PAYMENT": 2, 
                                 "CASH_IN": 3, "TRANSFER": 4,
                                 "DEBIT": 5})
data["isFraud"] = data["isFraud"].map({0: "No Fraud", 1: "Fraud"})
print(data.head())



# splitting the data
from sklearn.model_selection import train_test_split
x = np.array(data[["type", "amount", "oldbalanceOrg", "newbalanceOrig"]])
y = np.array(data[["isFraud"]])


# training a machine learning model
from sklearn.tree import DecisionTreeClassifier
xtrain, xtest, ytrain, ytest = train_test_split(x, y, test_size=0.10, random_state=42)
model = DecisionTreeClassifier()
model.fit(xtrain, ytrain)
print(model.score(xtest, ytest))

# prediction
#features = [type, amount, oldbalanceOrg, newbalanceOrig]
features = np.array([[4, 9000.60, 9000.60, 0.0]])
print(model.predict(features))

#SVM didnt work need to check why taking long time to run
# from sklearn.svm import LinearSVC
# modelsvm = LinearSVC()
# modelsvm.fit(xtrain,ytrain)
# print(modelsvm.score(xtest,ytest))


from sklearn.linear_model import LinearRegression

data1 = pd.read_csv("E:\DA-Project\Online Payments Fraud Detection\PS_20174392719_1491204439457_log.csv")
data1["type"] = data1["type"].map({"CASH_OUT": 1, "PAYMENT": 2, 
                                 "CASH_IN": 3, "TRANSFER": 4,
                                 "DEBIT": 5})

from sklearn.model_selection import train_test_split
x1 = np.array(data1[["type", "amount", "oldbalanceOrg", "newbalanceOrig"]])
y1 = np.array(data1[["isFraud"]])

xtrain1, xtest1, ytrain1, ytest1 = train_test_split(x1, y1, test_size=0.10, random_state=42)

modellr = LinearRegression()
modellr.fit(xtrain1, ytrain1)


features1 = np.array([[4, 9000.60, 9000.60, 0.0]])
print(modellr.predict(features1))
