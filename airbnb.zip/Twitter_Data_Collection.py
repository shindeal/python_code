# -*- coding: utf-8 -*-
"""
Created on Wed Mar  2 15:11:14 2022

@author: abc
"""

from twython import Twython
import json
import seaborn as sns
import matplotlib.pyplot as plt
sns.set(rc={'figure.figsize':(11, 4)})

with open("twitter_credentials.json","r") as file:
    creds=json.load(file)
    

python_tweets = Twython(creds['CONSUMER_KEY'],creds['CONSUMER_SECRET'])

#print(Twython.get_place_trends(python_tweets))



query = {'q':'Good Friday',
        'result_type':'popular',
        'count':100,
        'lang':'en',
        'until':'2022-04-10'
        }

sample_return = python_tweets.search(**query)

import pandas as pd

dict_={ 'user':[], 'date':[], 'text':[], 'favorite_count':[],'retweet_count' :[]}

for status in python_tweets.search(**query)['statuses']:
    dict_['user'].append(status['user']['screen_name'])
    dict_['date'].append(status['created_at'])
    dict_['text'].append(status['text'])
    dict_['favorite_count'].append(status['favorite_count'])
    dict_['retweet_count'].append(status['retweet_count'])
    
    
    
df = pd.DataFrame(dict_)
df.sort_values(by='favorite_count',inplace=True,ascending=False)

print(df.head(1))

df_time=pd.DataFrame(columns=['Date','RTweet_count','favorite_count'])
df_time['Date']=pd.to_datetime(df['date'],utc=True)
df_time['RTweet_count']=df['retweet_count']
df_time['favorite_count']=df['favorite_count']
df_time.sort_values(by='Date',inplace=True,ascending=True)
df_time = df_time.set_index('Date')






df_time['RTweet_count'].plot(linewidth=0.5);

cols_plot = ['RTweet_count', 'favorite_count']
axes = df_time[cols_plot].plot(marker='.', alpha=0.5, linestyle='None', figsize=(11, 9), subplots=True)
for ax in axes:
    ax.set_ylabel('Daily Totals tweets Data)')






##########through excel########checking date format###########
# =============================================================================
# df = pd.read_csv("live_tweets.csv", 
#                  parse_dates=['date_utc'], 
#                  dtype={'hour_utc':int,'minute_utc':int,'id':str}
#                 )
# =============================================================================

