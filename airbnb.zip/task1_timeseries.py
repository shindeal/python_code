# -*- coding: utf-8 -*-
"""
Created on Fri Apr 15 19:45:25 2022

@author: abc
"""

import pandas as pd


data = pd.read_csv("live_tweets.csv",sep=',',
                     parse_dates=['Date'], 
                     dtype={'hour_utc':int,'minute_utc':int})
leng = len(data)

#d1=pd.to_datetime(data.Date)

